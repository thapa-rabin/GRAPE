import pickle
import os

algos = ["gnn_mdi_v1", "knn_v1", "mean_v1", "mice_v1", "spectral_v1", "svd_v1"]
datasets = ["concrete", "energy", "housing", "kin8nm", "naval", "power", "protein", "yacht"]
for i in algos:
    for j in datasets:
        os.chdir('/users/PLS0144/rthapa01/grape/uci/mdi_results/results/' + i + '/' + j + '/0')
        with open('result.pkl','rb') as pickle_in:
            pickle_out = pickle.load(pickle_in)
        with open('result.txt','w+') as outfile:
            outfile.write(str(pickle_out))