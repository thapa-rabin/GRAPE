import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import json

rmse_array = [0.4417566322941253, 0.21336781015726222, 0.2525316241548143, 0.18746747910212072, 0.30655758691577134, 0.168]

x = np.arange(1)  # the label locations
width = 0.10  # the width of the bars

fig, ax = plt.subplots()
rects1 = ax.bar(x - 3*width, rmse_array[0], width, label="Spectral")
rects2 = ax.bar(x - 2*width, rmse_array[1], width, label="Mean")
rects3 = ax.bar(x - width, rmse_array[2], width, label="KNN")
rects4 = ax.bar(x, rmse_array[3], width, label="MICE")
rects5 = ax.bar(x + width, rmse_array[4], width, label="SVD")
rects6 = ax.bar(x + 2*width, rmse_array[5], width, label="GRAPE")


# Add some text for labels, title and custom x-axis tick labels, etc.
ax.set_ylabel('test_rmse')
ax.set_xlabel('Algorithms')
ax.set_title('Feature Imputation on time-series data (missing rate 0.3)')
ax.set_xticks([])
#ax.set_xticklabels(datasets)
ax.legend()
fig.tight_layout()

plt.savefig('barplot.png')
