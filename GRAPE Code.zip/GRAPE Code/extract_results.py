import json
import os

algos = ["knn_v1", "mean_v1", "mice_v1", "spectral_v1", "svd_v1"]
datasets = ["concrete", "energy","housing", "kin8nm", "naval", "power", "protein", "yacht"]

data_dict = {}
for j in datasets:
    data_dict[j] = {}
    for i in algos:
        data_dict[j][i] = {}
        path = '/users/PLS0144/rthapa01/grape/uci/mdi_results/results/' + i + '/' + j + '/0' 
        if (os.path.exists(path+"/result.txt")):
            os.chdir(path)
            with open('result.txt','r') as file:
                for line in file:
                    for word in line.split(','):
                        if(word[0:7] == " 'rmse'"):
                            rmse = float(word[9: ])
                            data_dict[j][i]["rmse"] = rmse
                        if(word[0:6] == " 'mae'"):
                            mae = float(word[8: ])
                            data_dict[j][i]["mae"] = mae
        else:
            continue
   
os.chdir('/users/PLS0144/rthapa01/grape')
with open('data_dict.json', 'w+') as f:
    json.dump(data_dict, f, indent=4)                      