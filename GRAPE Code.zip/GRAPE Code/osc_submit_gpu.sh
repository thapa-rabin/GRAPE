#!/bin/sh 

#SBATCH --gpus-per-node=1 

#SBATCH --account=pls0144 
#SBATCH --time=02:00:00 
#SBATCH --constraint=40core  
#SBATCH -J grapeGnn 
#SBATCH -o gnnJob-%j.out 
#SBATCH --mail-type=END 
#SBATCH --mail-user=rthapa01@student.ysu.edu 

module load python 
module load cuda/11.0.3  
source activate grape-gpu 

srun python baseline_uci_mdi_all.py  > resultsBaseline.txt 
#srun python train_uci_mdi_all.py  > resultsGNN.txt 

#srun python train_uci_y_all.py > resultsY.txt
#srun python train_y.py uci --data yacht
#srun python train_y.py uci --data kin8nm
#srun python train_y.py uci --data power
#srun python train_y.py uci --data protein
#srun python train_y.py uci --data naval
#srun python train_y.py uci --data concrete
#srun python train_y.py uci --data housing
#srun python train_y.py uci --data energy
#srun python train_y.py uci --data all_var