import pandas as pd

df = pd.read_csv("data.txt")

#df.to_csv("data.txt",index=False,sep='\t',header=False)