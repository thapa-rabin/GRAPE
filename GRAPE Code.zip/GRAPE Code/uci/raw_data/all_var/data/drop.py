import pandas as pd

#with open("d.txt") as infile, open("data.txt","w+") as outfile:
 #   for line in infile:
  #      outfile.write(line.replace(',','\t'),index=False)

df = pd.read_csv("d.txt", delimiter=',')

df.to_csv("data.txt",index=False,sep='\t',header=False)