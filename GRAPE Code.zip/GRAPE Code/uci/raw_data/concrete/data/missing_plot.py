#added by rthapa01
import missingno
import pandas as pd
import matplotlib
import matplotlib.pyplot as plt
import numpy as np

def get_known_mask(known_prob, edge_num):
    known_mask = (torch.FloatTensor(edge_num, 1).uniform_() < known_prob).view(-1)
    return known_mask

def construct_missing_X_from_mask(train_mask, df):
    nrow, ncol = df.shape
    data_incomplete = np.zeros((nrow, ncol))
    data_complete = np.zeros((nrow, ncol)) 
    train_mask = train_mask.reshape(nrow, ncol)
    for i in range(nrow):
        for j in range(ncol):
            data_complete[i,j] = df.iloc[i,j]
            if train_mask[i,j]:
                data_incomplete[i,j] = df.iloc[i,j]
            else:
                data_incomplete[i,j] = np.NaN
    return data_complete, data_incomplete

dataset=pd.read_csv("data.txt",delimiter="\t")
dataset.columns = ["Cement",  "Slag", "Fly Ash", "Water", "Super", "Coarse", "Fine", "Age", "Strength"]
mask = np.random.random(dataset.shape)<0.3

#dataset_with_missing_values = construct_missing_X_from_mask(mask,dataset)
dataset_with_missing_values = dataset.mask(mask)
#print(mask)

#missingno.matrix(data,figsize=(10,5), fontsize=12);
missingno.matrix(dataset_with_missing_values,figsize=(8,5), sparkline=False, fontsize=10,labels=True, color=(.25, .2, .3))
#missingno.matrix(mask)
plt.savefig("missing_plot.png")